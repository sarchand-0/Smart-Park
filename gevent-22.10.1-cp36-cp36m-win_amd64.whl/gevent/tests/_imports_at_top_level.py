# We simply import a stdlib module
__import__('netrc')
